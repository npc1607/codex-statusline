package app

import (
	"flag"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strings"
	"time"

	"codex-statusline/internal/ui"
	"codex-statusline/internal/usage"
)

type outputMode string

const (
	outputModeAuto    outputMode = "auto"
	outputModeCompact outputMode = "compact"
	outputModePretty  outputMode = "pretty"
)

func Run() int {
	home, err := os.UserHomeDir()
	if err != nil {
		return 0
	}

	defaultCacheFile := filepath.Join(home, ".codex", "tmp", "usage-status-cache.json")

	usageURL := flag.String("url", envOrDefault("CODEX_USAGE_URL", usage.DefaultURL), "usage API endpoint")
	keyFlag := flag.String("key", strings.TrimSpace(os.Getenv("CODEX_USAGE_KEY")), "usage API key")
	timeout := flag.Duration("timeout", 1100*time.Millisecond, "HTTP timeout")
	cacheTTL := flag.Duration("cache-ttl", 55*time.Second, "local cache ttl")
	cacheFile := flag.String("cache-file", defaultCacheFile, "cache file path")
	modeFlag := flag.String("mode", envOrDefault("CODEX_USAGE_MODE", string(outputModeAuto)), "output mode: auto, compact, pretty")
	flag.Parse()

	mode := resolveOutputMode(parseOutputMode(*modeFlag), os.Stdout)

	key := strings.TrimSpace(*keyFlag)
	if key == "" {
		key = usage.ReadKeyFromAuth(filepath.Join(home, ".codex", "auth.json"))
	}

	cfg := usage.Config{
		UsageURL:  *usageURL,
		Key:       key,
		Timeout:   *timeout,
		CacheTTL:  *cacheTTL,
		CacheFile: *cacheFile,
	}

	if cfg.Key == "" {
		if mode == outputModePretty {
			_, _ = fmt.Fprintln(os.Stdout, ui.RenderError(usage.ErrMissingKey))
		}
		return 0
	}

	if mode == outputModePretty {
		return runPrettyUI(cfg)
	}

	snapshot, err := usage.LoadSnapshot(cfg)
	if err != nil {
		return 0
	}

	_, _ = io.WriteString(os.Stdout, usage.FormatCompactLine(snapshot.Data))
	return 0
}

func runPrettyUI(cfg usage.Config) int {
	if err := ui.RunDashboard(cfg, os.Stdout); err != nil {
		snapshot, loadErr := usage.LoadSnapshot(cfg)
		if loadErr == nil {
			_, _ = fmt.Fprintln(os.Stdout, ui.RenderDashboard(snapshot))
			return 0
		}

		_, _ = fmt.Fprintln(os.Stdout, ui.RenderError(loadErr))
	}

	return 0
}

func parseOutputMode(value string) outputMode {
	switch strings.ToLower(strings.TrimSpace(value)) {
	case string(outputModeCompact):
		return outputModeCompact
	case string(outputModePretty):
		return outputModePretty
	default:
		return outputModeAuto
	}
}

func resolveOutputMode(mode outputMode, stdout *os.File) outputMode {
	if mode != outputModeAuto {
		return mode
	}

	if isTerminal(stdout) {
		return outputModePretty
	}

	return outputModeCompact
}

func isTerminal(file *os.File) bool {
	info, err := file.Stat()
	if err != nil {
		return false
	}

	return info.Mode()&os.ModeCharDevice != 0
}

func envOrDefault(key string, fallback string) string {
	value := strings.TrimSpace(os.Getenv(key))
	if value == "" {
		return fallback
	}

	return value
}

package usage

import (
	"errors"
	"time"
)

const (
	DefaultURL  = "https://codexzh.com/api/v1/usage/stats"
	tokenPerUSD = 500000.0
)

var ErrMissingKey = errors.New("missing API key: set CODEX_USAGE_KEY or OPENAI_API_KEY in ~/.codex/auth.json")

type DataSource string

const (
	SourceLive  DataSource = "live"
	SourceCache DataSource = "cache"
)

type Config struct {
	UsageURL  string
	Key       string
	Timeout   time.Duration
	CacheTTL  time.Duration
	CacheFile string
}

type Response struct {
	Success bool   `json:"success"`
	Message string `json:"message"`
	Data    Data   `json:"data"`
}

type Data struct {
	DailyQuota         float64 `json:"dailyQuota"`
	WeeklyQuota        float64 `json:"weeklyQuota"`
	TodayUsed          float64 `json:"todayUsed"`
	WeekUsed           float64 `json:"weekUsed"`
	TotalUsed          float64 `json:"totalUsed"`
	TodayCalls         int64   `json:"todayCalls"`
	TotalCalls         int64   `json:"totalCalls"`
	RPM                int64   `json:"rpm"`
	TPM                int64   `json:"tpm"`
	TodayUsedFormatted string  `json:"todayUsedFormatted"`
	WeekUsedFormatted  string  `json:"weekUsedFormatted"`
	TotalUsedFormatted string  `json:"totalUsedFormatted"`
	SubscriptionStart  string  `json:"subscriptionStart"`
	SubscriptionEnd    string  `json:"subscriptionEnd"`
}

type CachePayload struct {
	TS   int64  `json:"ts"`
	Line string `json:"line"`
	Data Data   `json:"data"`
}

type Snapshot struct {
	Data        Data
	Source      DataSource
	GeneratedAt time.Time
	Warning     string
}

type Summary struct {
	DailyTotalUSD       float64
	WeeklyTotalUSD      float64
	TodayUsedUSD        float64
	WeekUsedUSD         float64
	TodayUsedText       string
	WeekUsedText        string
	TotalUsedText       string
	TodayCalls          int64
	TotalCalls          int64
	RPM                 int64
	TPM                 int64
	TodayRemainingUSD   float64
	WeekRemainingUSD    float64
	TodayRemainingToken int64
	WeekRemainingToken  int64
}

package usage

import (
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"strings"
	"time"
)

func ReadKeyFromAuth(filePath string) string {
	data, err := os.ReadFile(filePath)
	if err != nil {
		return ""
	}

	var payload map[string]any
	if err := json.Unmarshal(data, &payload); err != nil {
		return ""
	}

	raw, _ := payload["OPENAI_API_KEY"].(string)
	return strings.TrimSpace(raw)
}

func LoadSnapshot(cfg Config) (Snapshot, error) {
	cache := readCache(cfg.CacheFile)
	if cache != nil {
		cachedAt := time.UnixMilli(cache.TS)
		if time.Since(cachedAt) < cfg.CacheTTL {
			return Snapshot{
				Data:        cache.Data,
				Source:      SourceCache,
				GeneratedAt: cachedAt,
			}, nil
		}
	}

	data, err := fetchUsage(cfg.UsageURL, cfg.Key, cfg.Timeout)
	if err == nil {
		snapshot := Snapshot{
			Data:        data,
			Source:      SourceLive,
			GeneratedAt: time.Now(),
		}

		writeCache(cfg.CacheFile, CachePayload{
			TS:   snapshot.GeneratedAt.UnixMilli(),
			Line: FormatCompactLine(data),
			Data: data,
		})

		return snapshot, nil
	}

	if cache != nil {
		return Snapshot{
			Data:        cache.Data,
			Source:      SourceCache,
			GeneratedAt: time.UnixMilli(cache.TS),
			Warning:     HumanizeFetchError(err),
		}, nil
	}

	return Snapshot{}, err
}

func HumanizeFetchError(err error) string {
	if err == nil {
		return ""
	}

	message := strings.TrimSpace(err.Error())
	if message == "" {
		return "unknown error"
	}

	switch {
	case strings.Contains(message, "401"):
		return "鉴权失败，或订阅已过期"
	case strings.Contains(strings.ToLower(message), "timeout"):
		return "请求超时"
	default:
		return message
	}
}

func readCache(filePath string) *CachePayload {
	data, err := os.ReadFile(filePath)
	if err != nil {
		return nil
	}

	var payload CachePayload
	if err := json.Unmarshal(data, &payload); err != nil {
		return nil
	}

	if payload.Line == "" || payload.TS == 0 {
		return nil
	}

	return &payload
}

func writeCache(filePath string, payload CachePayload) {
	if err := os.MkdirAll(filepath.Dir(filePath), 0o755); err != nil {
		return
	}

	data, err := json.Marshal(payload)
	if err != nil {
		return
	}

	_ = os.WriteFile(filePath, data, 0o644)
}

func fetchUsage(baseURL string, key string, timeout time.Duration) (Data, error) {
	endpoint, err := url.Parse(baseURL)
	if err != nil {
		return Data{}, err
	}

	query := endpoint.Query()
	query.Set("key", key)
	endpoint.RawQuery = query.Encode()

	req, err := http.NewRequest(http.MethodGet, endpoint.String(), nil)
	if err != nil {
		return Data{}, err
	}
	req.Header.Set("Content-Type", "application/json")

	client := &http.Client{Timeout: timeout}
	resp, err := client.Do(req)
	if err != nil {
		return Data{}, err
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return Data{}, err
	}

	var payload Response
	if err := json.Unmarshal(body, &payload); err != nil {
		if resp.StatusCode < 200 || resp.StatusCode >= 300 {
			return Data{}, fmt.Errorf("unexpected status: %s", resp.Status)
		}
		return Data{}, err
	}

	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		if strings.TrimSpace(payload.Message) != "" {
			return Data{}, fmt.Errorf("%s: %s", resp.Status, payload.Message)
		}
		return Data{}, fmt.Errorf("unexpected status: %s", resp.Status)
	}

	if !payload.Success {
		if strings.TrimSpace(payload.Message) != "" {
			return Data{}, fmt.Errorf("api error: %s", payload.Message)
		}
		return Data{}, errors.New("api error: request failed")
	}

	return payload.Data, nil
}

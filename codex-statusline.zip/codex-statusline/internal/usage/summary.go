package usage

import (
	"fmt"
	"math"
	"strings"
)

func FormatCompactLine(data Data) string {
	summary := Summarize(data)
	return strings.Join([]string{
		fmt.Sprintf("D %s/$%.2f", summary.TodayUsedText, summary.DailyTotalUSD),
		fmt.Sprintf("W %s/$%.2f", summary.WeekUsedText, summary.WeeklyTotalUSD),
		fmt.Sprintf("C %d/%d", summary.TodayCalls, summary.TotalCalls),
		fmt.Sprintf("R %d", summary.RPM),
		fmt.Sprintf("T %s", CompactNumber(summary.TPM)),
	}, " | ")
}

func Summarize(data Data) Summary {
	dailyTotal := data.DailyQuota / tokenPerUSD
	weeklyTotal := data.WeeklyQuota / tokenPerUSD
	todayRemainingUSD := maxFloat(dailyTotal-data.TodayUsed, 0)
	weekRemainingUSD := maxFloat(weeklyTotal-data.WeekUsed, 0)

	return Summary{
		DailyTotalUSD:       dailyTotal,
		WeeklyTotalUSD:      weeklyTotal,
		TodayUsedUSD:        data.TodayUsed,
		WeekUsedUSD:         data.WeekUsed,
		TodayUsedText:       fallbackMoney(data.TodayUsedFormatted, data.TodayUsed),
		WeekUsedText:        fallbackMoney(data.WeekUsedFormatted, data.WeekUsed),
		TotalUsedText:       fallbackMoney(data.TotalUsedFormatted, data.TotalUsed),
		TodayCalls:          data.TodayCalls,
		TotalCalls:          data.TotalCalls,
		RPM:                 data.RPM,
		TPM:                 data.TPM,
		TodayRemainingUSD:   todayRemainingUSD,
		WeekRemainingUSD:    weekRemainingUSD,
		TodayRemainingToken: usdToToken(todayRemainingUSD),
		WeekRemainingToken:  usdToToken(weekRemainingUSD),
	}
}

func FormatMoney(value float64) string {
	return fmt.Sprintf("$%.2f", value)
}

func CompactNumber(value int64) string {
	switch {
	case value >= 1000000:
		return fmt.Sprintf("%.1fM", float64(value)/1000000)
	case value >= 1000:
		return fmt.Sprintf("%.1fk", float64(value)/1000)
	default:
		return fmt.Sprintf("%d", value)
	}
}

func SafeRatio(used float64, total float64) float64 {
	if total <= 0 {
		return 0
	}

	ratio := used / total
	switch {
	case ratio < 0:
		return 0
	case ratio > 1:
		return 1
	default:
		return ratio
	}
}

func FormatPercent(ratio float64) string {
	return fmt.Sprintf("%.0f%%", SafeRatio(ratio, 1)*100)
}

func fallbackMoney(text string, value float64) string {
	if strings.TrimSpace(text) != "" {
		return text
	}

	return fmt.Sprintf("$%.2f", value)
}

func usdToToken(value float64) int64 {
	if value <= 0 {
		return 0
	}

	return int64(math.Round(value * tokenPerUSD))
}

func maxFloat(a float64, b float64) float64 {
	if a > b {
		return a
	}

	return b
}

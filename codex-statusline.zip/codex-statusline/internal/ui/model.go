package ui

import (
	"io"
	"os"
	"time"

	tea "charm.land/bubbletea/v2"
	"codex-statusline/internal/usage"
)

type spinnerTickMsg struct{}

type loadUsageMsg struct {
	snapshot usage.Snapshot
	err      error
}

type dashboardModel struct {
	cfg          usage.Config
	spinnerFrame int
	snapshot     *usage.Snapshot
	err          error
}

var spinnerFrames = []string{"|", "/", "-", "\\"}

func RunDashboard(cfg usage.Config, out io.Writer) error {
	program := tea.NewProgram(
		newDashboardModel(cfg),
		tea.WithOutput(out),
		// This dashboard exits quickly; suppress Bubble Tea's async 2026/2027
		// mode probes so their replies don't leak back into the shell prompt.
		tea.WithEnvironment(append(os.Environ(),
			"TERM=xterm-256color",
			"TERM_PROGRAM=Apple_Terminal",
		)),
	)

	_, err := program.Run()
	return err
}

func newDashboardModel(cfg usage.Config) dashboardModel {
	return dashboardModel{cfg: cfg}
}

func (m dashboardModel) Init() tea.Cmd {
	return tea.Batch(spinnerTick(), loadUsageCmd(m.cfg))
}

func (m dashboardModel) Update(msg tea.Msg) (tea.Model, tea.Cmd) {
	switch typed := msg.(type) {
	case spinnerTickMsg:
		if m.snapshot != nil || m.err != nil {
			return m, nil
		}

		m.spinnerFrame = (m.spinnerFrame + 1) % len(spinnerFrames)
		return m, spinnerTick()
	case loadUsageMsg:
		if typed.err != nil {
			m.err = typed.err
			return m, tea.Quit
		}

		m.snapshot = &typed.snapshot
		return m, tea.Quit
	default:
		return m, nil
	}
}

func (m dashboardModel) View() tea.View {
	switch {
	case m.snapshot != nil:
		return tea.NewView(RenderDashboard(*m.snapshot))
	case m.err != nil:
		return tea.NewView(RenderError(m.err))
	default:
		return tea.NewView(renderLoadingView(m.spinnerFrame))
	}
}

func spinnerTick() tea.Cmd {
	return tea.Tick(120*time.Millisecond, func(time.Time) tea.Msg {
		return spinnerTickMsg{}
	})
}

func loadUsageCmd(cfg usage.Config) tea.Cmd {
	return func() tea.Msg {
		snapshot, err := usage.LoadSnapshot(cfg)
		return loadUsageMsg{snapshot: snapshot, err: err}
	}
}

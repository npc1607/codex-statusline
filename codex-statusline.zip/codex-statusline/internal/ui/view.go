package ui

import (
	"errors"
	"fmt"
	"image/color"
	"math"
	"strings"
	"time"

	"codex-statusline/internal/usage"

	lipgloss "charm.land/lipgloss/v2"
)

const (
	quotaCardWidth = 34
	infoCardWidth  = 20
	subCardWidth   = 28
	noteCardWidth  = 70
	barWidth       = 22
)

var (
	beijingTZ = time.FixedZone("UTC+8", 8*60*60)

	colorPrimary = lipgloss.Color("39")
	colorGood    = lipgloss.Color("42")
	colorWarn    = lipgloss.Color("214")
	colorDanger  = lipgloss.Color("203")
	colorMuted   = lipgloss.Color("244")
	colorBorder  = lipgloss.Color("240")
	colorWhite   = lipgloss.Color("255")

	titleStyle = lipgloss.NewStyle().Bold(true).Foreground(colorPrimary)
	metaStyle  = lipgloss.NewStyle().Foreground(colorMuted)
	cardStyle  = lipgloss.NewStyle().
			Border(lipgloss.RoundedBorder()).
			BorderForeground(colorBorder).
			Padding(0, 1)
	noteStyle = lipgloss.NewStyle().
			Border(lipgloss.NormalBorder()).
			BorderForeground(colorBorder).
			Padding(0, 1).
			Width(noteCardWidth)
)

type subscriptionView struct {
	status string
	start  string
	end    string
	accent color.Color
}

func RenderDashboard(snapshot usage.Snapshot) string {
	summary := usage.Summarize(snapshot.Data)

	topRow := lipgloss.JoinHorizontal(
		lipgloss.Top,
		renderQuotaCard("今日额度", summary.TodayUsedText, summary.TodayUsedUSD, summary.DailyTotalUSD, summary.TodayRemainingUSD, summary.TodayRemainingToken),
		" ",
		renderQuotaCard("本周额度", summary.WeekUsedText, summary.WeekUsedUSD, summary.WeeklyTotalUSD, summary.WeekRemainingUSD, summary.WeekRemainingToken),
	)

	bottomRow := lipgloss.JoinHorizontal(
		lipgloss.Top,
		renderInfoCard("调用统计", colorPrimary, []string{
			fmt.Sprintf("今日 %d 次", summary.TodayCalls),
			fmt.Sprintf("累计 %d 次", summary.TotalCalls),
			fmt.Sprintf("累计 %s", summary.TotalUsedText),
		}, infoCardWidth),
		" ",
		renderInfoCard("当前速率", colorPrimary, []string{
			fmt.Sprintf("%d 次/分", summary.RPM),
			fmt.Sprintf("%s tok/分", usage.CompactNumber(summary.TPM)),
			"字段: RPM / TPM",
		}, infoCardWidth),
		" ",
		renderSubscriptionCard(snapshot.Data),
	)

	return strings.Join([]string{
		renderHeader(snapshot),
		"",
		topRow,
		"",
		bottomRow,
		"",
		renderSourceNote(snapshot),
	}, "\n")
}

func RenderError(err error) string {
	lines := []string{
		lipgloss.NewStyle().Bold(true).Foreground(colorDanger).Render("无法获取使用统计"),
		usage.HumanizeFetchError(err),
	}

	if errors.Is(err, usage.ErrMissingKey) {
		lines = append(lines,
			"设置 CODEX_USAGE_KEY，或在 ~/.codex/auth.json 中写入 OPENAI_API_KEY。",
			metaStyle.Render("紧凑模式下无可用 key 时会保持静默。"),
		)
	}

	return strings.Join([]string{
		renderHeader(usage.Snapshot{Source: usage.SourceCache, GeneratedAt: time.Now().In(beijingTZ)}),
		"",
		cardStyle.Copy().Width(noteCardWidth).BorderForeground(colorDanger).Render(strings.Join(lines, "\n")),
	}, "\n")
}

func renderLoadingView(frame int) string {
	card := cardStyle.Copy().Width(noteCardWidth).Render(strings.Join([]string{
		lipgloss.NewStyle().Bold(true).Foreground(colorPrimary).Render("正在获取 CodexZH 使用统计"),
		fmt.Sprintf("%s 请求 usage/stats 接口并整理配额、调用与订阅信息", spinnerFrames[frame]),
		metaStyle.Render("终端里默认显示完整面板，非终端场景继续输出紧凑单行。"),
	}, "\n"))

	return strings.Join([]string{
		renderHeader(usage.Snapshot{Source: usage.SourceLive, GeneratedAt: time.Now().In(beijingTZ)}),
		"",
		card,
	}, "\n")
}

func renderHeader(snapshot usage.Snapshot) string {
	stamp := snapshot.GeneratedAt.In(beijingTZ)
	if snapshot.GeneratedAt.IsZero() {
		stamp = time.Now().In(beijingTZ)
	}

	return lipgloss.JoinHorizontal(
		lipgloss.Center,
		titleStyle.Render("CodexZH 使用统计"),
		"  ",
		renderSourceBadge(snapshot),
		"  ",
		metaStyle.Render("更新 "+stamp.Format("15:04:05")),
	)
}

func renderSourceBadge(snapshot usage.Snapshot) string {
	label := "实时"
	accent := colorGood

	if snapshot.Source == usage.SourceCache {
		label = "缓存"
		accent = colorWarn
	}

	return lipgloss.NewStyle().
		Bold(true).
		Foreground(colorWhite).
		Background(accent).
		Padding(0, 1).
		Render(label)
}

func renderQuotaCard(title string, usedText string, usedUSD float64, totalUSD float64, remainingUSD float64, remainingToken int64) string {
	ratio := usage.SafeRatio(usedUSD, totalUSD)
	accent := quotaColor(ratio)

	lines := []string{
		lipgloss.NewStyle().Bold(true).Foreground(accent).Render(title),
		lipgloss.NewStyle().Bold(true).Render(fmt.Sprintf("%s / $%.2f", usedText, totalUSD)),
		renderBar(ratio, barWidth, accent) + " " + lipgloss.NewStyle().Foreground(accent).Render(usage.FormatPercent(ratio)),
		fmt.Sprintf("剩余 %s | %s tok", usage.FormatMoney(remainingUSD), usage.CompactNumber(remainingToken)),
	}

	return cardStyle.Copy().Width(quotaCardWidth).Render(strings.Join(lines, "\n"))
}

func renderInfoCard(title string, accent color.Color, lines []string, width int) string {
	content := append([]string{lipgloss.NewStyle().Bold(true).Foreground(accent).Render(title)}, lines...)
	return cardStyle.Copy().Width(width).Render(strings.Join(content, "\n"))
}

func renderSubscriptionCard(data usage.Data) string {
	view := summarizeSubscription(data)
	return renderInfoCard("订阅状态", view.accent, []string{
		view.status,
		"开始 " + view.start,
		"到期 " + view.end,
	}, subCardWidth)
}

func summarizeSubscription(data usage.Data) subscriptionView {
	start := parseBeijingTime(data.SubscriptionStart)
	end := parseBeijingTime(data.SubscriptionEnd)

	view := subscriptionView{
		status: "未提供",
		start:  "--",
		end:    "--",
		accent: colorMuted,
	}

	if !start.IsZero() {
		view.start = start.In(beijingTZ).Format("2006-01-02")
	}
	if !end.IsZero() {
		view.end = end.In(beijingTZ).Format("2006-01-02")
	}

	if end.IsZero() {
		if !start.IsZero() {
			view.status = "已开通"
			view.accent = colorPrimary
		}
		return view
	}

	now := time.Now().In(beijingTZ)
	if now.After(end) {
		view.status = "已过期"
		view.accent = colorDanger
		return view
	}

	hoursLeft := end.Sub(now).Hours()
	switch {
	case hoursLeft < 24:
		view.status = "今日到期"
		view.accent = colorWarn
	case hoursLeft < 72:
		view.status = fmt.Sprintf("剩余 %d 天", int(math.Ceil(hoursLeft/24)))
		view.accent = colorWarn
	default:
		view.status = fmt.Sprintf("剩余 %d 天", int(math.Ceil(hoursLeft/24)))
		view.accent = colorGood
	}

	return view
}

func parseBeijingTime(value string) time.Time {
	value = strings.TrimSpace(value)
	if value == "" {
		return time.Time{}
	}

	parsed, err := time.ParseInLocation("2006-01-02 15:04:05", value, beijingTZ)
	if err != nil {
		return time.Time{}
	}

	return parsed
}

func renderSourceNote(snapshot usage.Snapshot) string {
	message := fmt.Sprintf("实时请求成功，结果已刷新本地缓存。更新时间 %s。", snapshot.GeneratedAt.In(beijingTZ).Format("15:04:05"))
	borderColor := colorBorder

	if snapshot.Source == usage.SourceCache {
		message = fmt.Sprintf("命中本地缓存，缓存年龄 %s。", formatAge(time.Since(snapshot.GeneratedAt)))
		borderColor = colorWarn
	}
	if snapshot.Warning != "" {
		message = fmt.Sprintf("接口暂不可用，展示最近一次成功结果。原因: %s。", snapshot.Warning)
		borderColor = colorWarn
	}

	return noteStyle.Copy().BorderForeground(borderColor).Render(message)
}

func quotaColor(ratio float64) color.Color {
	switch {
	case ratio >= 0.85:
		return colorDanger
	case ratio >= 0.65:
		return colorWarn
	default:
		return colorGood
	}
}

func renderBar(ratio float64, width int, accent color.Color) string {
	ratio = usage.SafeRatio(ratio, 1)
	filled := int(math.Round(ratio * float64(width)))
	if filled > width {
		filled = width
	}
	if filled < 0 {
		filled = 0
	}

	full := strings.Repeat("#", filled)
	empty := strings.Repeat("-", width-filled)

	return lipgloss.NewStyle().Foreground(accent).Render(full) +
		lipgloss.NewStyle().Foreground(colorMuted).Render(empty)
}

func formatAge(duration time.Duration) string {
	switch {
	case duration < time.Minute:
		return fmt.Sprintf("%ds", int(duration.Seconds()))
	case duration < time.Hour:
		return fmt.Sprintf("%dm", int(duration.Minutes()))
	default:
		return fmt.Sprintf("%dh", int(duration.Hours()))
	}
}
